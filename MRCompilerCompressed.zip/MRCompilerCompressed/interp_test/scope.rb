def f()
  a = 4 # lokale variabele
end
a = 3
f()
print a
