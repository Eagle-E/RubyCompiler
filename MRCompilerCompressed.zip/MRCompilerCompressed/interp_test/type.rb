a = 42 # a heeft type int
b = (a < 100) # b heeft type bool
c = b + 6 # type error
b = 77 # nieuwe definitie van b
c = b + 6
