print "Hello "; print "world!\n" # kommapunt en newline zijn separators
print "Hello "
print "again!\n"
