#include "Statement.h"

Statement::~Statement()
{

}