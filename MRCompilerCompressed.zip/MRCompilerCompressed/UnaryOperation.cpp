#include "UnaryOperation.h"

UnaryOperation::UnaryOperation()
{
}