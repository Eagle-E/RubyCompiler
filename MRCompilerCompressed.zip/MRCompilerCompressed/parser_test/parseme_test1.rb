def f (x,y) z = x+y; return z end
def h3a (x) return x+3; end
undef h3a
a = 7; beek = 3+a
if a<b 
then a+=4 
elsif a <= b
  beek*=2
else a/=b end
c = true
while a > 0 do a -= 1 end
until ((!(a < 3)) && true) do a += 1 end
case a when 7 then print(-7)
  when 6 then print(-6)
  when 3 then print(-3)
  else print(0)
end
print(a)
