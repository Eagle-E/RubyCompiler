a = 3
case a 
  when 7 then print(-7)
end
print(a)
